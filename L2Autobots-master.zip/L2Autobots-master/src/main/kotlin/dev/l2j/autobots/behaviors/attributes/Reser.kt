package dev.l2j.autobots.behaviors.attributes

interface Reser {
}