package dev.l2j.autobots.behaviors.preferences

internal enum class AttackPlayerType {
    None,
    Flagged,
    Innocent
}