package dev.l2j.autobots.behaviors.preferences

enum class TargetingPreference {
    Random,
    Closest
}