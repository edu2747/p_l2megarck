package dev.l2j.autobots.models

internal data class AutobotLoc(var x: Int, var y: Int, var z: Int)