package dev.l2j.autobots.models

enum class BotDebugAction {
    VisualizeVision
}