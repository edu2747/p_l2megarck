package dev.l2j.autobots.models

internal enum class ChatType {
    All,
    Hero,
    PmReceived,
    PmSent,
    Shout,
    Trade
}