package dev.l2j.autobots.models

enum class RespawnAction {
    None,
    ReturnToDeathLocation,
    Logout
}