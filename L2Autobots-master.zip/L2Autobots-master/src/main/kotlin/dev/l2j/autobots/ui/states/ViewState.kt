package dev.l2j.autobots.ui.states

interface ViewState {
    var isActive: Boolean
    fun reset()
}