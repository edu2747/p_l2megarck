package dev.l2j.autobots.ui.tabs

internal enum class IndexTab {
    General,
    Clan,
    Ally
}

internal enum class IndexBotOrdering{
    None,
    LevelAsc,
    LevelDesc,
    OnAsc,
    OnDesc
}