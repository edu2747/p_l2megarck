package dev.l2j.autobots.utils

const val beastSoulShotId = 6645
const val beastSpiritShotId = 6647